import math as m
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import scipy.linalg as LA
import csv
import sys
from sympy import symbols, diff # use these two lib to make partial derivatives
import os, sys
from mpl_toolkits import mplot3d

matplotlib.rc("font", size = 20)
matplotlib.rc("font", family = "Arial")

T = 10 # time up to 10s
C = 1 # 1s^-1
L = 1 # 1m
D = [1, 10, 100] # cm^2/s
N = 101 # number of grids
dt = 1e-3
steps = 1000 # number of steps
dx = L/(N-1)
nx = L/dx + 1
nplot = 30
r = D[0]*dt/(2*dx**2) # D[i] i = 0, 1, 2 representing 1, 10, 100; change over here!
s = dt/2

M1 = np.identity(N-2) #since can not use first (u0) and last item (un)
M2 = np.identity(N-2)
c = np.zeros((N-2))


for i in np.arange(N-2):
    if i == 0:
        M1[i, :] = [1-s+2*r if j == 0 else (-r) if j == N-3 else 0 for j in np.arange(N-2)]
        M2[i, :] = [1+s-2*r if j == 0 else r if j == N-3 else 0 for j in np.arange(N-2)]
        c[i] = 0
    elif i == N-3:
        M1[i, :] = [-r if j == N-4 else 2+2*r if j == N-3 else 0 for j in np.arange(N-2)]
        M2[i, :] = [r if j == N-4 else 2-2*r if j == N-3 else 0 for j in np.arange(N-2)]
        c[i] = 0
    else:
        M1[i, :] = [-r if j == i-1 or j == i+1 else 2+2*r if j == i else 0 for j in np.arange(N-2)]
        M2[i, :] = [r if j == i-1 or j == i+1 else 2-2*r if j == i else 0 for j in np.arange(N-2)]
# Ultimately want M1 Un+1 = M2 Un
u = np.arange(N)
u[0] = 0; u[-1] = 0
b = M2.dot(u[1:-1]) + c
#print(u0)
x = np.linspace(0, 1, N)
rhs = M2.dot(u[1:-1]) + c

fig = plt.figure()
ax = plt.axes(projection='3d')


Lx = []
Ly = []
Lz = []
u = u[1:-1]
for t in np.arange(0, T, dt):
    for i in np.arange(N-2):
        x = -L/2 + i*dx
        Lx.append(t)
        Ly.append(x)
        Lz.append(u[i])
    u = M2.dot(u)
# for t in np.arange(0, T, dt):
#     for j in np.arange(nx):
#         x = -L/2.0 + j*dx
#         Lx.append(t)
#         Ly.append(x)
#         Lz.append(u[int(j)])
#     u = np.dot(M2, u[1:-1])


Lx = np.asarray(Lx)
Ly = np.asarray(Ly)
Lz = np.asarray(Lz)
ax.plot3D(Lx, Ly, Lz)
ax.set_xlabel('t')
ax.set_ylabel('x')
ax.set_zlabel('u')
#print(Lx, "\n")

plt.show()










